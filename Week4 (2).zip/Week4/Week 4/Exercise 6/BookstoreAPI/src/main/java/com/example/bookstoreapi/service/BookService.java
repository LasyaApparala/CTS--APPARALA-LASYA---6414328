package com.example.bookstoreapi.service;

import com.example.bookstoreapi.exception.BookNotFoundException;
import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    private final List<Book> books = new ArrayList<>();
    private Long nextId = 1L;

    // Find a book by ID
    public Book findBookById(Long id) {
        Optional<Book> book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst();
        return book.orElseThrow(() -> new BookNotFoundException("Book with ID " + id + " not found"));
    }

    // Save a new book
    public Book saveBook(Book book) {
        book.setId(nextId++);
        books.add(book);
        return book;
    }

    // Delete a book by ID
    public void deleteBookById(Long id) {
        boolean removed = books.removeIf(book -> book.getId().equals(id));
        if (!removed) {
            throw new BookNotFoundException("Book with ID " + id + " not found");
        }
    }

    // List all books
    public List<Book> findAllBooks() {
        return new ArrayList<>(books);
    }
}
