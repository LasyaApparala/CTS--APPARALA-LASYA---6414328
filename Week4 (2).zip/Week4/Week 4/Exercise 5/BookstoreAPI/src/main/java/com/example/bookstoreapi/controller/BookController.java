package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookWithCustomHeaders(@PathVariable Long id) {
        Book book = bookService.findBookById(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomHeaderValue");

        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Book> createBookWithCustomHeaders(@RequestBody Book book) {
        Book createdBook = bookService.saveBook(book);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/api/books/" + createdBook.getId());
        headers.add("Custom-Header", "BookCreated");

        return new ResponseEntity<>(createdBook, headers, HttpStatus.CREATED);
    }
}
