package com.example.bookstoreapi.controller;


import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.awt.print.Book;
import java.util.List;
@RestController
public class BookController {
    private final ObservationRegistry observationRegistry;

    public BookController(ObservationRegistry observationRegistry) {
        this.observationRegistry = observationRegistry;
    }

    @GetMapping("/books")
    public List<Book> getAllBooks() {
        return Observation.createNotStarted("books.getAll", observationRegistry)
                .observe(this::findAllBooks);
    }

    private List<Book> findAllBooks() {
        // Fetch books from the database
        return List.of(new Book());
    }
}

