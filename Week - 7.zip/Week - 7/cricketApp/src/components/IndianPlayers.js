import React from 'react';

export function OddPlayers(players) {
  const entries = Object.values(players)[0];
  return (
    <ul>
      {entries.filter((_, index) => index % 2 === 0).map((player, index) => (
        <li key={index}> {["First", "Third", "Fifth"][index]} : {player}</li>
      ))}
    </ul>
  );
}

export function EvenPlayers(players) {
  const entries = Object.values(players)[0];
  return (
    <ul>
      {entries.filter((_, index) => index % 2 !== 0).map((player, index) => (
        <li key={index}> {["Second", "Fourth", "Sixth"][index]} : {player}</li>
      ))}
    </ul>
  );
}

export function ListofIndianPlayers({ IndianPlayers }) {
  return (
    <ul>
      {IndianPlayers.map((player, index) => (
        <li key={index}>Mr. {player}</li>
      ))}
    </ul>
  );
}
