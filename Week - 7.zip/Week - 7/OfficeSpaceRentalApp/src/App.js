import React from 'react';
import OfficeList from './components/OfficeList';

function App() {
  return (
    <div>
      <OfficeList />
    </div>
  );
}

export default App;
