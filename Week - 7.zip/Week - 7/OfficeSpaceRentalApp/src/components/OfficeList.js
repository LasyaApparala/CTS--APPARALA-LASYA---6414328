import React from 'react';

// import local images
import office1 from '../assets/office1.jpeg';
import office2 from '../assets/office2.jpeg';
import office3 from '../assets/office3.jpeg';

// Office data array with local image references
const offices = [
  {
    Name: "DBS",
    Rent: 50000,
    Address: "Chennai",
    Image: office1
  },
  {
    Name: "WeWork",
    Rent: 75000,
    Address: "Bangalore",
    Image: office2
  },
  {
    Name: "Regus",
    Rent: 60000,
    Address: "Hyderabad",
    Image: office3
  }
];

function OfficeList() {
  const heading = "Office Space";

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>{heading}, at Affordable Range</h1>

      {offices.map((office, index) => {
        const colorStyle = {
          color: office.Rent <= 60000 ? 'red' : 'green'
        };

        return (
          <div key={index} style={{ marginBottom: "40px" }}>
            <img
              src={office.Image}
              alt="Office"
              style={{ width: "300px", height: "200px", borderRadius: "10px" }}
            />
            <h2>Name: {office.Name}</h2>
            <h3 style={colorStyle}>Rent: Rs. {office.Rent}</h3>
            <h3>Address: {office.Address}</h3>
          </div>
        );
      })}
    </div>
  );
}

export default OfficeList;
