export const blogs = [
  {
    id: 1,
    title: 'React Learning',
    author: 'Stephen Biz',
    content: 'Welcome to learning React!',
  },
  {
    id: 2,
    title: 'Installation',
    author: 'Schewzdenier',
    content: 'You can install React from npm.',
  },
];
