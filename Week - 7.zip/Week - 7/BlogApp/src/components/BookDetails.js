import React from 'react';
import { books } from '../data/books';

function BookDetails() {
  return (
    <div style={{ borderLeft: '3px solid green', paddingLeft: '20px' }}>
      <h1>Book Details</h1>
      {books.length > 0 ? (
        books.map(book => (
          <div key={book.id}>
            <h3>{book.bname}</h3>
            <h4>{book.price}</h4>
          </div>
        ))
      ) : (
        <p>No books available</p>
      )}
    </div>
  );
}

export default BookDetails;
