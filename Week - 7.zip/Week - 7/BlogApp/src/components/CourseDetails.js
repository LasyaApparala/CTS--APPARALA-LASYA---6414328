import React from 'react';
import { courses } from '../data/courses';

function CourseDetails() {
  return (
    <div style={{ borderLeft: '3px solid green', paddingLeft: '20px' }}>
      <h1>Course Details</h1>
      {courses.length && courses.map(course => (
        <div key={course.id}>
          <h3>{course.name}</h3>
          <p>{course.date}</p>
        </div>
      ))}
    </div>
  );
}

export default CourseDetails;
