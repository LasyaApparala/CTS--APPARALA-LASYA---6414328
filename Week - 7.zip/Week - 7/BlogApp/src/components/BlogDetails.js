import React from 'react';
import { blogs } from '../data/blogs';

function BlogDetails() {
  return (
    <div style={{ borderLeft: '3px solid green', paddingLeft: '20px' }}>
      <h1>Blog Details</h1>
      {blogs.map(blog => (
        <div key={blog.id}>
          <h3>{blog.title}</h3>
          <h4><i>{blog.author}</i></h4>
          <p>{blog.content}</p>
        </div>
      ))}
    </div>
  );
}

export default BlogDetails;
