import React, { Component } from 'react';

class CurrencyConvertor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      amount: '',
      convertedAmount: '',
    };

    // Binding `this` for class methods
    this.handleChange = this.handleChange.bind(this);
    this.handleConvert = this.handleConvert.bind(this);
  }

  handleChange(e) {
    this.setState({ amount: e.target.value });
  }

  handleConvert(e) {
    e.preventDefault();
    const { amount } = this.state;
    const euroRate = 0.011; // 1 INR = 0.011 EUR approx
    const converted = (parseFloat(amount) * euroRate).toFixed(2);
    this.setState({ convertedAmount: converted });
  }

  render() {
    return (
      <div style={{ textAlign: "center", padding: "20px" }}>
        <h2 style={{ color: 'green' }}>Currency Convertor!!!</h2>
        <form onSubmit={this.handleConvert}>
          <label>
            Amount in ₹:
            <input type="number" value={this.state.amount} onChange={this.handleChange} />
          </label>
          <br /><br />
          <button type="submit">Convert to €</button>
        </form>
        <h3>
          {this.state.convertedAmount && `€ ${this.state.convertedAmount}`}
        </h3>
      </div>
    );
  }
}

export default CurrencyConvertor;
