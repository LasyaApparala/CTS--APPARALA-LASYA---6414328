import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      amount: '',
      convertedAmount: '',
    };
  }

  incrementAndGreet = () => {
    this.setState((prevState) => ({ count: prevState.count + 1 }));
    alert("Hello! Counter increased.");
  };

  decrement = () => {
    this.setState((prevState) => ({ count: prevState.count - 1 }));
  };

  sayWelcome = (message) => {
    alert(message);
  };

  handleClick = (e) => {
    e.preventDefault();
    alert("I was clicked");
  };

  handleAmountChange = (e) => {
    this.setState({ amount: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const inr = parseFloat(this.state.amount);
    if (!isNaN(inr)) {
      const eur = (inr * 0.011).toFixed(2);
      this.setState({ convertedAmount: eur });
    } else {
      alert("Enter a valid number.");
    }
  };

  render() {
    return (
      <div style={{ padding: '20px', textAlign: 'left', width: '50%' }}>
        <h2>React Event Examples App</h2>
        <h3>Counter: {this.state.count}</h3>

        <ul style={{ listStyleType: 'none', paddingLeft: 0 }}>
          <li>
            <button onClick={this.incrementAndGreet}>Increment</button>
          </li>
          <li>
            <button onClick={this.decrement}>Decrement</button>
          </li>
          <li>
            <button onClick={() => this.sayWelcome("Welcome")}>Say Welcome</button>
          </li>
          <li>
            <button onClick={this.handleClick}>Click on me</button>
          </li>
        </ul>

        <hr style={{ margin: '30px 0', border: '1px solid #ccc' }} />

        <h2 style={{ color: 'green' }}>Currency Converter</h2>
        <form onSubmit={this.handleSubmit}>
          <label>
            Amount in ₹:
            <input
              type="number"
              value={this.state.amount}
              onChange={this.handleAmountChange}
              style={{ marginLeft: '10px' }}
            />
          </label>
          <br /><br />
          <button type="submit">Convert to €</button>
        </form>

        {this.state.convertedAmount && (
          <h3>€ {this.state.convertedAmount}</h3>
        )}
      </div>
    );
  }
}

export default App;
